/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.tut.bl;

import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import za.ac.tut.entity.StudentFeedback;

/**
 *
 * @author Motsei PC
 */
@Stateless
public class StudentFeedbackFacade extends AbstractFacade<StudentFeedback> implements StudentFeedbackFacadeLocal {

    @PersistenceContext(unitName = "StudentFeedEJBModulePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public StudentFeedbackFacade() {
        super(StudentFeedback.class);
    }
    
}

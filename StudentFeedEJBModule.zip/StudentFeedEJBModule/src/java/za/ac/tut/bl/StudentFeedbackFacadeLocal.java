/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package za.ac.tut.bl;

import jakarta.ejb.Local;
import java.util.List;
import za.ac.tut.entity.StudentFeedback;

/**
 *
 * @author Motsei PC
 */
@Local
public interface StudentFeedbackFacadeLocal {

    void create(StudentFeedback studentFeedback);

    void edit(StudentFeedback studentFeedback);

    void remove(StudentFeedback studentFeedback);

    StudentFeedback find(Object id);

    List<StudentFeedback> findAll();

    List<StudentFeedback> findRange(int[] range);

    int count();
    
}
